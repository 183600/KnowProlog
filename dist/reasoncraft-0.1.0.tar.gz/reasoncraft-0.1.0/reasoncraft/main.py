import os
from pyswip import Prolog
# 修改导入，使用 zhipuai
from zhipuai import ZhipuAI
import re # For parsing predicate names if needed, and for argument generation

# --- 配置 ---
# 你的智谱AI API Key (JWT)
# !!! 警告: 直接硬编码 API Key 是不安全的实践。请使用环境变量。!!!
# 为了演示，我们暂时直接使用，但强烈建议修改为从环境变量读取。
ZHIPU_API_KEY = "b6e23abec9b746adb20cb0f3ae116f8e.LIlANJZWSUCbXLnX" # 请替换为你的真实 Key
# os.environ["ZHIPU_API_KEY"] = "你的实际API Key" # 推荐方式

try:
    # 初始化 ZhipuAI 客户端
    client = ZhipuAI(api_key=ZHIPU_API_KEY)
except Exception as e:
    print(f"ZhipuAI API key not found or invalid, or client initialization failed.")
    print(f"Error: {e}")
    print("Please ensure the ZHIPU_API_KEY is set correctly if using environment variables,")
    print("or that the hardcoded key is correct and valid.")
    exit()

PROLOG_KB_FILE = "knowledge_base.pl"
LLM_MODEL = "glm-4-flash" # 你指定的模型

# --- Prolog 接口 (与之前相同) ---
class PrologInterface:
    def __init__(self, kb_file):
        self.prolog = Prolog()
        try:
            self.prolog.consult(kb_file)
            print(f"Prolog knowledge base '{kb_file}' loaded successfully.")
        except Exception as e:
            print(f"Error loading Prolog knowledge base '{kb_file}': {e}")
            raise

    def query(self, prolog_query_string):
        print(f"Executing Prolog query: {prolog_query_string}")
        try:
            results = list(self.prolog.query(prolog_query_string))
            print(f"Prolog raw results: {results}")

            if not results:
                return {"success": False, "solutions": []}
            elif results == [{}]: # Typically means a query succeeded without variables, e.g., fact.
                return {"success": True, "solutions": [{}]}
            else:
                decoded_results = []
                for res_dict in results:
                    decoded_dict = {}
                    for k, v in res_dict.items():
                        if isinstance(v, bytes):
                            decoded_dict[k] = v.decode('utf-8')
                        else:
                            decoded_dict[k] = v
                    decoded_results.append(decoded_dict)
                return {"success": True, "solutions": decoded_results}
        except Exception as e:
            print(f"Error executing Prolog query '{prolog_query_string}': {e}")
            return {"success": False, "error": str(e), "solutions": []}

# --- LLM 接口 (修改为使用 ZhipuAI) ---
class LLMConverter:
    def __init__(self, model_name, prolog_interface): # Added prolog_interface
        self.model_name = model_name
        self.prolog_interface = prolog_interface # Store it
        self.prolog_schema = self._generate_prolog_schema_from_kb() # Generate and cache schema

    def _generate_prolog_schema_from_kb(self):
        """
        Dynamically generates the Prolog schema description by querying
        the loaded knowledge base for defined predicates.
        """
        print("Generating Prolog schema from knowledge base...")
        schema_parts = ["Available Prolog predicates:"]
        try:
            # Query for all user-defined predicates (Name/Arity)
            # current_predicate/1 might also be useful for just names, but Name/Arity is better.
            predicates_query = "current_predicate(PredicateName/Arity)"
            results = self.prolog_interface.query(predicates_query)

            if results["success"] and results["solutions"]:
                # Sort for consistent schema order, helpful for LLM if it sees it multiple times
                sorted_solutions = sorted(results["solutions"], key=lambda x: (x.get('PredicateName', ''), x.get('Arity', 0)))

                for sol in sorted_solutions:
                    name = sol.get('PredicateName')
                    arity = sol.get('Arity')

                    if name and isinstance(arity, int):
                        # Filter out some common SWI-Prolog internal predicates if desired
                        if name.startswith('$') or name.startswith('swi_'):
                            continue

                        # Generate argument placeholders like Arg1, Arg2, ... or X, Y, Z
                        # Using X, Y, Z for the first few, then V4, V5...
                        arg_vars = []
                        if arity > 0:
                            base_vars = ['X', 'Y', 'Z', 'A', 'B', 'C']
                            if arity <= len(base_vars):
                                arg_vars = base_vars[:arity]
                            else:
                                arg_vars = base_vars[:]
                                for i in range(len(base_vars) + 1, arity + 1):
                                    arg_vars.append(f"V{i}")
                        
                        args_str = ", ".join(arg_vars)
                        
                        # For auto-generated schema, precise descriptions are hard.
                        # We'll provide the signature and a generic comment.
                        # The LLM is usually smart enough to infer usage from the name.
                        if arity == 0:
                            schema_parts.append(f"- {name}.")
                        else:
                            schema_parts.append(f"- {name}({args_str}).")
                            # Example of adding a more descriptive placeholder if needed:
                            # schema_parts.append(f"- {name}({args_str}): Predicate '{name}' with {arity} argument(s).")
            else:
                schema_parts.append("- No predicates automatically detected or error querying predicates.")
                print("Warning: Could not automatically detect predicates from KB.")

        except Exception as e:
            print(f"Error generating schema from KB: {e}")
            schema_parts.append("- Error occurred while generating predicate list.")

        schema_parts.append("\nConstants (names, things) should be lowercase atoms (e.g., john, mary, apples).")
        schema_parts.append("Variables should be uppercase (e.g., X, Parent, Child).")
        schema_parts.append("Queries must end with a period (.).")
        
        generated_schema = "\n".join(schema_parts)
        print(f"Generated Schema:\n{generated_schema}")
        return generated_schema

    def _get_prolog_schema(self):
        # This now just returns the cached schema
        return self.prolog_schema

    def nl_to_prolog(self, natural_language_question):
        schema = self._get_prolog_schema() # Uses the cached schema
        system_prompt = f"""
        你是一位 Prolog 专家程序员。你的任务是根据提供的模式，将自然语言问题转换成一个有效的 Prolog 查询。

Prolog 模式：
{schema}

说明：

    仅使用模式中定义的谓词。
    确保所有常量（例如名字）均为小写。
    确保所有变量均为大写（例如：X, Y, Person）。
    查询必须以句点（.）结尾。
    如果问题是“是/否”类型的问题，Prolog 查询应反映这一点（例如：parent(john, mary).）。
    如果问题询问“谁”、“什么”等，则使用变量（例如：father(X, mary).）。
    仅输出 Prolog 查询。不要添加任何解释或介绍性文字。
    如果你无法根据模式自信地将问题转换为有效的查询，则输出确切的字符串 "CONVERSION_FAILED"。
        """
        user_prompt = f"""
        Natural Language Question:
        "{natural_language_question}"

        Prolog Query:
        """
        print(f"\n--- NL to Prolog Conversion ---")
        # print(f"LLM Input (System Prompt for NL to Prolog):\n{system_prompt}") # Can be verbose
        print(f"LLM Input (User Prompt for NL to Prolog):\n{user_prompt}")
        print(f"Using Schema (first 150 chars): {schema[:150]}...")


        try:
            response = client.chat.completions.create(
                model=self.model_name,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.1
            )
            prolog_query = response.choices[0].message.content.strip()
            print(f"LLM Output (Prolog Query): {prolog_query}")

            if prolog_query == "CONVERSION_FAILED" or not prolog_query.endswith('.'):
                 # Add a check for empty string as well, in case LLM fails silently
                if not prolog_query or prolog_query == "CONVERSION_FAILED":
                    print("LLM indicated conversion failed or returned empty.")
                    return None
                if not prolog_query.endswith('.'):
                    print(f"Warning: LLM generated query without a period: '{prolog_query}'. Attempting to fix.")
                    # Heuristic: if it looks like a query but just misses a period
                    if re.match(r"^[a-z_][a-zA-Z0-9_]*\(.*\)$", prolog_query) or \
                       re.match(r"^[a-z_][a-zA-Z0-9_]*$", prolog_query) :
                       prolog_query += "."
                       print(f"Appended period. New query: {prolog_query}")
                    else: # If it doesn't look like a simple query missing a period
                        print("Query format unexpected and does not end with a period. Treating as conversion failure.")
                        return None
            return prolog_query
        except Exception as e:
            print(f"Error during NL to Prolog conversion with ZhipuAI: {e}")
            return None

    def prolog_results_to_nl(self, original_question, prolog_query, prolog_results):
        system_prompt = "You are a helpful assistant."
        user_prompt = f"""
        The user asked the following question:
        "{original_question}"

        This question was translated into the Prolog query:
        `{prolog_query}`

        The Prolog query returned the following results:
        {prolog_results}

        Based on these results, provide a concise and natural language answer to the user's original question.
        - If `success` is `false` in the results, it might mean the query had an error or no information was found.
          If `error` is present, mention it. Otherwise, state that no information was found or the statement is false.
        - If `solutions` is an empty list `[]` (and success is true), it means the query is false or no answer was found for the given constants/variables.
        - If `solutions` is `[{{}}]` (and success is true), it means the query is true (for yes/no questions that don't bind variables).
        - If `solutions` contains dictionaries with variable bindings, use them to construct the answer.
          For example, if results are `{{'success': True, 'solutions': [{{'X': 'john'}}]}}` for a query like `father(X, mary).`,
          a good answer would be "John is the father of Mary." or "The father of Mary is John.".
        - If there are multiple solutions, list them clearly or summarize.

        Natural Language Answer:
        """
        print(f"\n--- Prolog Results to NL Conversion ---")
        # print(f"LLM Input (System Prompt for Prolog Results to NL):\n{system_prompt}") # Can be verbose
        print(f"LLM Input (User Prompt for Prolog Results to NL - first 200 chars of results):\n{user_prompt[:200 + len(original_question) + len(prolog_query) + 150]}...")


        try:
            response = client.chat.completions.create(
                model=self.model_name,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.7
            )
            nl_answer = response.choices[0].message.content.strip()
            print(f"LLM Output (Natural Language Answer): {nl_answer}")
            return nl_answer
        except Exception as e:
            print(f"Error during Prolog results to NL conversion with ZhipuAI: {e}")
            return "I encountered an error while trying to formulate the answer."

# --- Main Application Logic ---
def main():
    print("Initializing system...")
    try:
        prolog_interface = PrologInterface(PROLOG_KB_FILE)
    except Exception:
        print("Failed to initialize Prolog interface. Exiting.")
        return

    # Pass prolog_interface to LLMConverter
    llm_converter = LLMConverter(LLM_MODEL, prolog_interface)
    print(f"System initialized with ZhipuAI model: {LLM_MODEL}. You can now ask questions.")
    print("Type 'exit' or 'quit' to end the session.")

    while True:
        user_question = input("\nAsk a question: ")
        if user_question.lower() in ['exit', 'quit']:
            break

        if not user_question:
            continue

        # 1. NL to Prolog
        prolog_query = llm_converter.nl_to_prolog(user_question)

        if not prolog_query:
            print("LLM: I couldn't convert your question into a Prolog query. Please try rephrasing.")
            continue
        # CONVERSION_FAILED check is now inside nl_to_prolog, which returns None in that case

        # 2. Execute Prolog Query
        prolog_results = prolog_interface.query(prolog_query)

        # 3. Prolog Results to NL
        natural_language_answer = llm_converter.prolog_results_to_nl(user_question, prolog_query, prolog_results)

        # 4. Display Answer
        print(f"\nAnswer: {natural_language_answer}")

if __name__ == "__main__":
    # # Create a dummy knowledge_base.pl for testing if it doesn't exist
    # if not os.path.exists(PROLOG_KB_FILE):
    #     print(f"'{PROLOG_KB_FILE}' not found. Creating a dummy one for testing.")
    #     with open(PROLOG_KB_FILE, "w") as f:
    #         f.write("% Sample Knowledge Base\n")
    #         f.write("male(john).\n")
    #         f.write("male(peter).\n")
    #         f.write("female(mary).\n")
    #         f.write("female(lisa).\n")
    #         f.write("\n")
    #         f.write("parent(john, peter).\n")
    #         f.write("parent(mary, peter).\n")
    #         f.write("parent(john, lisa).\n")
    #         f.write("parent(mary, lisa).\n")
    #         f.write("\n")
    #         f.write("father(F, C) :- male(F), parent(F, C).\n")
    #         f.write("mother(M, C) :- female(M), parent(M, C).\n")
    #         f.write("\n")
    #         f.write("likes(john, apples).\n")
    #         f.write("likes(mary, oranges).\n")
    #         f.write("likes(peter, X) :- likes(john, X).\n") # Peter likes what John likes
    #         f.write("\n")
    #         f.write("happy(john).\n") # A fact (arity 0)
    #         f.write("sunny.\n")      # Another fact (arity 0)

    main()